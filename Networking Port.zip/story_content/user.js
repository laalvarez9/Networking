function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5WSjiNzvAUJ":
        Script1();
        break;
      case "5o5l34ujkjo":
        Script2();
        break;
      case "666epdvgG1R":
        Script3();
        break;
      case "6VxClQLIF2k":
        Script4();
        break;
      case "63cYKTyXZ1R":
        Script5();
        break;
      case "5s3n0uT6ZUe":
        Script6();
        break;
      case "6ENXATvLOIt":
        Script7();
        break;
      case "6L2lim3npks":
        Script8();
        break;
      case "5o72GHoKbbA":
        Script9();
        break;
      case "6EnZInqhUtl":
        Script10();
        break;
      case "6j5I0afOKKl":
        Script11();
        break;
      case "5W5TVSNsw9a":
        Script12();
        break;
      case "5WOJte3peVL":
        Script13();
        break;
      case "69kfOGkR4SM":
        Script14();
        break;
      case "6O85GVUod2n":
        Script15();
        break;
      case "5xbycxC7nQ6":
        Script16();
        break;
      case "5o59HZLIzwd":
        Script17();
        break;
  }
}

function Script1()
{
  DS.appState.onToggleVolume();
}

function Script2()
{
  DS.appState.onToggleVolume();
}

function Script3()
{
  DS.appState.onToggleVolume();
}

function Script4()
{
  DS.appState.onToggleVolume();
}

function Script5()
{
  DS.appState.onToggleVolume();
}

function Script6()
{
  DS.appState.onToggleVolume();
}

function Script7()
{
  DS.appState.onToggleVolume();
}

function Script8()
{
  DS.appState.onToggleVolume();
}

function Script9()
{
  DS.appState.onToggleVolume();
}

function Script10()
{
  DS.appState.onToggleVolume();
}

function Script11()
{
  DS.appState.onToggleVolume();
}

function Script12()
{
  DS.appState.onToggleVolume();
}

function Script13()
{
  DS.appState.onToggleVolume();
}

function Script14()
{
  DS.appState.onToggleVolume();
}

function Script15()
{
  DS.appState.onToggleVolume();
}

function Script16()
{
  DS.appState.onToggleVolume();
}

function Script17()
{
  DS.appState.onToggleVolume();
}

